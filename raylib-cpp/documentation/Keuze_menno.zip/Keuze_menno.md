## Framework / Menno

Voor dit project wil ik aan de gang met Raylib en voor programmeer taal kies ik om verder te gaan met C++